
const { default: makeWASocket, useMultiFileAuthState } = require("@adiwajshing/baileys");
const pino = require("pino");
const fs = require("fs");

async function connectBot() {
    const { state, saveCreds } = await useMultiFileAuthState("session");

    const sock = makeWASocket({
        logger: pino({ level: "silent" }),
        printQRInTerminal: true,
        auth: state,
    });

    sock.ev.on("creds.update", saveCreds);
    sock.ev.on("messages.upsert", async ({ messages }) => {
        const msg = messages[0];
        if (!msg.message) return;
        const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
        if (text && text.toLowerCase() === "bonjour") {
            await sock.sendMessage(msg.key.remoteJid, { text: "Bonjou! Mwen se KING AIRSEE bot ou." });
        }
    });
}

connectBot();
